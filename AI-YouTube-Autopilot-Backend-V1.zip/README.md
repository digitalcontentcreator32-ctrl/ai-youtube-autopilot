# AI YouTube Autopilot Backend V1

Backend foundation for Telegram control and Creator Agent jobs.

## Secret

Set the environment variable `TELEGRAM_BOT_TOKEN` in the cloud service.
Never put the token in GitHub.

## Commands

/start
/status
/create <request>
/stop

This V1 is a foundation only. Later stages add AI providers, video generation,
YouTube OAuth/upload, persistent database, payments, repair agent and scheduling.
